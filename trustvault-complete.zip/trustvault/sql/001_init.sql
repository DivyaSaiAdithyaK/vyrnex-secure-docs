-- TrustVault schema v1. Applied by scripts/migrate.ts inside one transaction.
CREATE TYPE user_role AS ENUM ('admin', 'owner', 'viewer');
CREATE TYPE perm_level AS ENUM ('read', 'edit');

CREATE TABLE users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email         text NOT NULL CHECK (email = lower(email) AND length(email) <= 254),
  name          text NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  password_hash text NOT NULL,
  role          user_role NOT NULL,
  disabled_at   timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_key ON users (email);

-- Only a SHA-256 hash of the session token is stored: a DB leak does not leak live sessions.
CREATE TABLE sessions (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);
CREATE INDEX sessions_user_idx ON sessions (user_id);

-- Metadata only. File bytes live in document_files so listings/search never touch them.
CREATE TABLE documents (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id      uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  name          text NOT NULL CHECK (length(name) BETWEEN 1 AND 200),
  description   text NOT NULL DEFAULT '' CHECK (length(description) <= 2000),
  category      text NOT NULL DEFAULT 'general',
  original_name text NOT NULL,
  mime_type     text NOT NULL,
  size_bytes    integer NOT NULL CHECK (size_bytes > 0),
  sha256        text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX documents_owner_idx    ON documents (owner_id);
CREATE INDEX documents_category_idx ON documents (category);
CREATE INDEX documents_created_idx  ON documents (created_at DESC);

CREATE TABLE document_files (
  document_id uuid PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,
  content     bytea NOT NULL
);

-- Revocation = DELETE of the row. There is no cache, so the next request sees it.
CREATE TABLE permissions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  level       perm_level NOT NULL,
  granted_by  uuid NOT NULL REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (document_id, user_id)
);
CREATE INDEX permissions_user_idx ON permissions (user_id);

-- ---------------------------------------------------------------------------
-- AUDIT TRAIL: append-only and hash-chained.
-- No foreign keys on purpose: deleting a user or document must never touch history,
-- so actor/document names are snapshotted as text.
-- ---------------------------------------------------------------------------
CREATE SEQUENCE audit_events_seq;
CREATE TABLE audit_events (
  seq            bigint PRIMARY KEY,
  id             uuid NOT NULL DEFAULT gen_random_uuid(),
  at             timestamptz NOT NULL DEFAULT clock_timestamp(),
  actor_id       uuid,
  actor_email    text,
  action         text NOT NULL,
  outcome        text NOT NULL CHECK (outcome IN ('success', 'denied', 'error')),
  reason         text,
  document_id    uuid,
  document_name  text,
  target_user_id uuid,
  ip             text,
  user_agent     text,
  details        jsonb NOT NULL DEFAULT '{}'::jsonb,
  prev_hash      text NOT NULL,
  hash           text NOT NULL
);
CREATE INDEX audit_at_idx       ON audit_events (at DESC);
CREATE INDEX audit_document_idx ON audit_events (document_id);
CREATE INDEX audit_actor_idx    ON audit_events (actor_id);

CREATE FUNCTION audit_row_hash(e audit_events) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  SELECT encode(sha256(convert_to(concat_ws('|',
    e.seq, e.id,
    to_char(e.at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US'),
    coalesce(e.actor_id::text, ''), coalesce(e.actor_email, ''),
    e.action, e.outcome, coalesce(e.reason, ''),
    coalesce(e.document_id::text, ''), coalesce(e.document_name, ''),
    coalesce(e.target_user_id::text, ''),
    coalesce(e.ip, ''), coalesce(e.user_agent, ''),
    e.details::text, e.prev_hash), 'UTF8')), 'hex')
$$;

-- The database, not the app, assigns seq/time/hash. A global lock serialises writers
-- so chain order always equals seq order.
CREATE FUNCTION audit_chain_insert() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE last_hash text;
BEGIN
  PERFORM pg_advisory_xact_lock(727274);
  SELECT hash INTO last_hash FROM audit_events ORDER BY seq DESC LIMIT 1;
  NEW.seq       := nextval('audit_events_seq');
  NEW.at        := clock_timestamp();
  NEW.prev_hash := coalesce(last_hash, repeat('0', 64));
  NEW.hash      := audit_row_hash(NEW);
  RETURN NEW;
END $$;
CREATE TRIGGER audit_chain_before_insert BEFORE INSERT ON audit_events
  FOR EACH ROW EXECUTE FUNCTION audit_chain_insert();

CREATE FUNCTION audit_block_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit_events is append-only (% blocked)', TG_OP USING ERRCODE = '42501';
END $$;
CREATE TRIGGER audit_no_update_delete BEFORE UPDATE OR DELETE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION audit_block_mutation();
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_events
  FOR EACH STATEMENT EXECUTE FUNCTION audit_block_mutation();

-- Recomputes the whole chain. Returns ok=false and the first bad seq if anything
-- was edited or a row removed from the middle.
CREATE FUNCTION verify_audit_chain()
RETURNS TABLE (ok boolean, broken_seq bigint, checked bigint, head_hash text)
LANGUAGE plpgsql STABLE AS $$
DECLARE r audit_events; expected_prev text := repeat('0', 64); n bigint := 0;
BEGIN
  FOR r IN SELECT * FROM audit_events ORDER BY seq LOOP
    IF r.prev_hash <> expected_prev OR r.hash <> audit_row_hash(r) THEN
      RETURN QUERY SELECT false, r.seq, n, NULL::text; RETURN;
    END IF;
    expected_prev := r.hash; n := n + 1;
  END LOOP;
  RETURN QUERY SELECT true, NULL::bigint, n, expected_prev;
END $$;
