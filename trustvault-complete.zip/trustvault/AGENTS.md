# Working rules given to the AI assistant (reused every session)

1. Authorisation is decided on the server, per request, by ONE function: `authorize(user, document, action)`.
   Never in a component, never cached, never skipped "because the route is internal".
2. Unauthorised access to a document returns 404 (not 403) so existence is not revealed, and is audited as `denied`.
3. Every handler: authenticate -> validate input (Zod) -> authorize -> act -> audit. Refused attempts are audited too.
4. No signed URLs, share links or file tokens. Files stream only through the authenticated download route.
5. The audit table is append-only; only `src/server/audit` writes to it; never log passwords, tokens or file contents.
6. No test may pass by disabling or mocking authorisation. Prove each test can fail (remove the control, watch it fail).
7. Never claim something works unless a command was run and its output seen. Never invent dates, commits or results.
