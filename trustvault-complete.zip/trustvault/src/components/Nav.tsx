"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { api } from "@/lib/api";

export function Nav({ user }: { user: { name: string; role: string } }) {
  const path = usePathname();
  const router = useRouter();
  async function out() { try { await api("/api/auth/logout", { method: "POST" }); } finally { router.push("/login"); router.refresh(); } }
  const on = (p: string) => (path.startsWith(p) ? "on" : "");
  return (
    <header className="nav"><div className="wrap">
      <Link href="/dashboard" className="logo"><i />TrustVault</Link>
      <nav className="links" aria-label="Main">
        <Link href="/dashboard" className={on("/dashboard") || on("/documents")}>Documents</Link>
        {user.role === "admin" && <Link href="/admin" className={on("/admin")}>Admin</Link>}
      </nav>
      <div className="who"><span>{user.name}</span><span className="badge">{user.role}</span><button className="btn sm" onClick={out}>Sign out</button></div>
    </div></header>
  );
}
