"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { api, ApiError, CATEGORIES, fmtDate, fmtSize } from "@/lib/api";
import { Alert, Badge, Empty, Spinner } from "./ui";

type Detail = { document: { id: string; name: string; description: string; category: string; originalName: string; mimeType: string; sizeBytes: number; sha256: string; createdAt: string; updatedAt: string; ownerName: string; ownerEmail: string };
  access: "owner" | "edit" | "read"; can: { edit: boolean; share: boolean; delete: boolean } };

export function DocumentDetail({ id }: { id: string }) {
  const router = useRouter();
  const [d, setD] = useState<Detail | null>(null);
  const [missing, setMissing] = useState(false); const [error, setError] = useState("");
  const load = useCallback(async () => {
    try { setD(await api<Detail>(`/api/documents/${id}`)); }
    catch (e) { if (e instanceof ApiError && e.status === 404) setMissing(true); else setError((e as Error).message); }
  }, [id]);
  useEffect(() => { load(); }, [load]);

  if (missing) return <div className="card"><Empty title="Document not found">It does not exist, or you do not have access. <br /><Link href="/dashboard">Back to documents</Link></Empty></div>;
  if (error) return <Alert>{error}</Alert>;
  if (!d) return <Spinner />;
  const doc = d.document;

  async function remove() {
    if (!confirm(`Permanently delete "${doc.name}" and revoke everyone's access?`)) return;
    try { await api(`/api/documents/${id}`, { method: "DELETE" }); router.push("/dashboard"); router.refresh(); } catch (e) { setError((e as Error).message); }
  }
  return (
    <>
      <p><Link href="/dashboard">← Documents</Link></p>
      <div className="row" style={{ alignItems: "center" }}><div><h1>{doc.name}</h1>
        <p className="sub">{doc.originalName} · {fmtSize(doc.sizeBytes)} · {doc.category} · owned by {doc.ownerName}</p></div>
        <Badge kind={d.access}>{d.access}</Badge>
        <a className="btn primary" href={`/api/documents/${id}/download`}>Download</a>
        {d.can.delete && <button className="btn danger" onClick={remove}>Delete</button>}</div>
      <div className="grid g2">
        <div className="card"><h2>Details</h2>{doc.description && <p>{doc.description}</p>}
          <p className="mono">Uploaded {fmtDate(doc.createdAt)}<br />Updated {fmtDate(doc.updatedAt)}<br />SHA-256 {doc.sha256}</p></div>
        {d.can.edit && <EditForm id={id} doc={doc} onSaved={load} />}
      </div>
      {d.can.share && <><Share id={id} /><Activity id={id} /></>}
    </>
  );
}

function EditForm({ id, doc, onSaved }: { id: string; doc: Detail["document"]; onSaved: () => void }) {
  const [busy, setBusy] = useState(false); const [err, setErr] = useState(""); const [ok, setOk] = useState("");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr(""); setOk("");
    try { await api(`/api/documents/${id}`, { method: "PATCH", body: new FormData(e.currentTarget) }); setOk("Saved."); onSaved(); }
    catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  }
  return (
    <form className="card" onSubmit={submit}><h2>Edit</h2>
      <label htmlFor="en">Name</label><input id="en" name="name" defaultValue={doc.name} required maxLength={200} />
      <label htmlFor="ec">Category</label><select id="ec" name="category" defaultValue={doc.category}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
      <label htmlFor="ed">Description</label><input id="ed" name="description" defaultValue={doc.description} maxLength={2000} />
      <label htmlFor="ef">Replace file (optional)</label><input id="ef" name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx,.pptx,.txt,.csv" />
      <Alert>{err}</Alert><Alert kind="ok">{ok}</Alert>
      <button className="btn primary" style={{ marginTop: 12 }} disabled={busy}>{busy ? "Saving..." : "Save changes"}</button></form>
  );
}

type Perm = { user_id: string; name: string; email: string; level: "read" | "edit"; created_at: string };
function Share({ id }: { id: string }) {
  const [perms, setPerms] = useState<Perm[] | null>(null); const [err, setErr] = useState(""); const [email, setEmail] = useState(""); const [level, setLevel] = useState("read");
  const load = useCallback(async () => { try { setPerms((await api<{ permissions: Perm[] }>(`/api/documents/${id}/permissions`)).permissions); } catch (e) { setErr((e as Error).message); } }, [id]);
  useEffect(() => { load(); }, [load]);
  async function grant(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    try { await api(`/api/documents/${id}/permissions`, { method: "POST", body: JSON.stringify({ email, level }) }); setEmail(""); load(); } catch (x) { setErr((x as Error).message); }
  }
  async function revoke(uid: string) { setErr(""); try { await api(`/api/documents/${id}/permissions/${uid}`, { method: "DELETE" }); load(); } catch (x) { setErr((x as Error).message); } }
  return (
    <div className="card" style={{ marginTop: 14 }}><h2>Who has access</h2>
      <form className="row" onSubmit={grant}>
        <div><label htmlFor="ge">Grant access to (email)</label><input id="ge" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div style={{ maxWidth: 140 }}><label htmlFor="gl">Level</label><select id="gl" value={level} onChange={(e) => setLevel(e.target.value)}><option value="read">read</option><option value="edit">edit</option></select></div>
        <button className="btn primary">Grant</button></form>
      <Alert>{err}</Alert>
      {perms === null ? <Spinner /> : perms.length === 0 ? <p className="sub">Only you can access this document.</p> :
        perms.map((p) => <div className="doc" key={p.user_id}><div className="m"><b>{p.name}</b><small>{p.email} · since {fmtDate(p.created_at)}</small></div>
          <Badge kind={p.level}>{p.level}</Badge><button className="btn sm danger" onClick={() => revoke(p.user_id)}>Revoke</button></div>)}
    </div>
  );
}

type Ev = { seq: number; at: string; actor_email: string | null; action: string; outcome: string; reason: string | null };
function Activity({ id }: { id: string }) {
  const [ev, setEv] = useState<Ev[] | null>(null); const [err, setErr] = useState("");
  useEffect(() => { api<{ events: Ev[] }>(`/api/documents/${id}/activity`).then((r) => setEv(r.events)).catch((e) => setErr(e.message)); }, [id]);
  return (
    <div className="card" style={{ marginTop: 14 }}><h2>Activity on this document</h2><Alert>{err}</Alert>
      {ev === null ? !err && <Spinner /> : ev.length === 0 ? <p className="sub">No activity yet.</p> :
        <div className="tablewrap"><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Result</th></tr></thead><tbody>
          {ev.map((e) => <tr key={e.seq}><td>{fmtDate(e.at)}</td><td>{e.actor_email ?? "-"}</td><td>{e.action}</td>
            <td><Badge kind={e.outcome}>{e.outcome}</Badge>{e.reason ? ` ${e.reason}` : ""}</td></tr>)}</tbody></table></div>}
    </div>
  );
}
