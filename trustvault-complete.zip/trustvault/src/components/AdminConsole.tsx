"use client";
import { useCallback, useEffect, useState } from "react";
import { api, fmtDate } from "@/lib/api";
import { Alert, Badge, Empty, Spinner } from "./ui";

type Ev = { seq: number; at: string; actor_email: string | null; action: string; outcome: string; reason: string | null; document_name: string | null; ip: string | null; hash: string };
type Verify = { ok: boolean; brokenSeq: number | null; checked: number; headHash: string | null };

export function AdminConsole() {
  const [stats, setStats] = useState<Record<string, number> | null>(null);
  const [events, setEvents] = useState<Ev[] | null>(null); const [more, setMore] = useState(false);
  const [f, setF] = useState({ outcome: "", action: "", q: "" });
  const [err, setErr] = useState(""); const [v, setV] = useState<Verify | null>(null); const [vb, setVb] = useState(false);

  const load = useCallback(async (before?: number) => {
    setErr("");
    try {
      const qs = new URLSearchParams(Object.entries({ ...f, limit: "50", ...(before ? { before: String(before) } : {}) }).filter(([, x]) => x));
      const r = await api<{ events: Ev[] }>(`/api/admin/audit?${qs}`);
      setEvents((prev) => (before && prev ? [...prev, ...r.events] : r.events)); setMore(r.events.length === 50);
    } catch (e) { setErr((e as Error).message); setEvents([]); }
  }, [f]);
  useEffect(() => { const t = setTimeout(() => load(), 250); return () => clearTimeout(t); }, [load]);
  useEffect(() => { api<Record<string, number>>("/api/admin/stats").then(setStats).catch((e) => setErr(e.message)); }, []);

  async function verify() { setVb(true); try { setV(await api<Verify>("/api/admin/audit/verify")); } catch (e) { setErr((e as Error).message); } finally { setVb(false); } }
  const S = ({ k, label }: { k: string; label: string }) => <div className="card stat"><b>{stats ? stats[k] : "-"}</b><span>{label}</span></div>;

  return (
    <>
      <h1>Administration</h1><p className="sub">Document activity and permission changes. Administrators see activity, not document contents.</p>
      <div className="grid g3"><S k="events" label="Audit events" /><S k="refused_24h" label="Refused attempts (24h)" /><S k="downloads_24h" label="Downloads (24h)" />
        <S k="permission_changes_24h" label="Permission changes (24h)" /><S k="documents" label="Documents" /><S k="users" label="Users" /></div>
      <div className="card" style={{ margin: "16px 0" }}><div className="row" style={{ alignItems: "center" }}>
        <div><h2 style={{ margin: 0 }}>Audit chain integrity</h2><p className="sub" style={{ margin: 0 }}>Recomputes every hash in the trail and reports the first altered row.</p></div>
        <button className="btn primary" onClick={verify} disabled={vb}>{vb ? "Verifying..." : "Verify now"}</button></div>
        {v && <Alert kind={v.ok ? "ok" : "err"}>{v.ok ? `Chain intact: ${v.checked} events verified.` : `TAMPERING DETECTED at event #${v.brokenSeq} (${v.checked} verified before it).`}</Alert>}
        {v?.ok && v.headHash && <p className="mono">Head hash {v.headHash}<br />Record this value somewhere outside the database: it also exposes deletion of the newest rows.</p>}</div>
      <div className="card"><h2>Audit log</h2>
        <div className="row">
          <div><label htmlFor="af">Outcome</label><select id="af" value={f.outcome} onChange={(e) => setF({ ...f, outcome: e.target.value })}><option value="">All</option><option>success</option><option>denied</option><option>error</option></select></div>
          <div><label htmlFor="aa">Action prefix</label><input id="aa" placeholder="e.g. permission." value={f.action} onChange={(e) => setF({ ...f, action: e.target.value })} /></div>
          <div><label htmlFor="aq">User or document</label><input id="aq" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} /></div></div>
        <Alert>{err}</Alert>
        {events === null ? <Spinner /> : events.length === 0 ? <Empty title="No events match" /> : (
          <div className="tablewrap"><table><thead><tr><th>#</th><th>When</th><th>Who</th><th>Action</th><th>Result</th><th>Document</th><th>IP</th></tr></thead><tbody>
            {events.map((e) => <tr key={e.seq}><td>{e.seq}</td><td>{fmtDate(e.at)}</td><td>{e.actor_email ?? "-"}</td><td>{e.action}</td>
              <td><Badge kind={e.outcome}>{e.outcome}</Badge>{e.reason ? ` ${e.reason}` : ""}</td><td className="wrapc">{e.document_name ?? "-"}</td><td>{e.ip ?? "-"}</td></tr>)}</tbody></table></div>)}
        {more && <button className="btn" style={{ marginTop: 12 }} onClick={() => events && load(events[events.length - 1]?.seq)}>Load older</button>}</div>
    </>
  );
}
