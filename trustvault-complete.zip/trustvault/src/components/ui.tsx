export const Spinner = () => <div className="spin" role="status" aria-label="Loading" />;
export const Alert = ({ kind = "err", children }: { kind?: "err" | "ok"; children: React.ReactNode }) =>
  children ? <div className={`alert ${kind}`} role={kind === "err" ? "alert" : "status"}>{children}</div> : null;
export const Empty = ({ title, children }: { title: string; children?: React.ReactNode }) => (
  <div className="empty"><h2>{title}</h2><div>{children}</div></div>
);
export const Badge = ({ kind, children }: { kind?: string; children: React.ReactNode }) => <span className={`badge ${kind ?? ""}`}>{children}</span>;
