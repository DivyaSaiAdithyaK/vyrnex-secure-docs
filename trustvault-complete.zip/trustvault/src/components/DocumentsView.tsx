"use client";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, CATEGORIES, fmtDate, fmtSize, type Doc } from "@/lib/api";
import { Alert, Badge, Empty, Spinner } from "./ui";

export function DocumentsView({ role }: { role: string }) {
  const [docs, setDocs] = useState<Doc[] | null>(null);
  const [error, setError] = useState("");
  const [f, setF] = useState({ q: "", owner: "", category: "", from: "", to: "" });
  const seq = useRef(0);

  const load = useCallback(async () => {
    const n = ++seq.current; setError("");
    try {
      const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
      const r = await api<{ documents: Doc[] }>(`/api/documents?${qs}`);
      if (n === seq.current) setDocs(r.documents);
    } catch (e) { if (n === seq.current) { setError((e as Error).message); setDocs([]); } }
  }, [f]);
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const filtered = Object.values(f).some(Boolean);

  return (
    <>
      <h1>Documents</h1>
      <p className="sub">{role === "owner" ? "Your documents and those shared with you." : "Documents that have been shared with you."}</p>
      {role === "owner" && <UploadForm onDone={load} />}
      <div className="card" style={{ margin: "16px 0" }}>
        <div className="row">
          <div><label htmlFor="q">Name</label><input id="q" placeholder="Search by name" value={f.q} onChange={set("q")} /></div>
          <div><label htmlFor="o">Owner</label><input id="o" placeholder="Owner name or email" value={f.owner} onChange={set("owner")} /></div>
          <div><label htmlFor="c">Category</label><select id="c" value={f.category} onChange={set("category")}><option value="">All</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label htmlFor="fr">From</label><input id="fr" type="date" value={f.from} onChange={set("from")} /></div>
          <div><label htmlFor="to">To</label><input id="to" type="date" value={f.to} onChange={set("to")} /></div>
          {filtered && <button className="btn" onClick={() => setF({ q: "", owner: "", category: "", from: "", to: "" })}>Clear</button>}
        </div>
      </div>
      <Alert>{error}</Alert>
      {docs === null ? <Spinner /> : docs.length === 0 && !error ? (
        <div className="card"><Empty title={filtered ? "No matching documents" : "No documents yet"}>
          {filtered ? "Try different filters." : role === "owner" ? "Upload your first document above." : "Nothing has been shared with you yet."}</Empty></div>
      ) : (
        <div className="card list">{docs.map((d) => (
          <div className="doc" key={d.id}>
            <div className="m"><Link href={`/documents/${d.id}`}><b>{d.name}</b></Link>
              <small>{d.owner_name} · {d.category} · {fmtSize(d.size_bytes)} · {fmtDate(d.created_at)}</small></div>
            <Badge kind={d.access}>{d.access}</Badge>
            <a className="btn sm" href={`/api/documents/${d.id}/download`}>Download</a>
          </div>))}</div>
      )}
    </>
  );
}

function UploadForm({ onDone }: { onDone: () => void }) {
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState(""); const [err, setErr] = useState("");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const form = e.currentTarget; setBusy(true); setErr(""); setMsg("");
    try { await api("/api/documents", { method: "POST", body: new FormData(form) }); form.reset(); setMsg("Uploaded."); onDone(); }
    catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  }
  return (
    <form className="card" onSubmit={submit}>
      <h2>Upload a document</h2>
      <div className="row">
        <div><label htmlFor="un">Name</label><input id="un" name="name" required maxLength={200} /></div>
        <div><label htmlFor="uc">Category</label><select id="uc" name="category">{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label htmlFor="uf">File (max 4 MB)</label><input id="uf" name="file" type="file" required accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx,.pptx,.txt,.csv" /></div>
      </div>
      <label htmlFor="ud">Description (optional)</label><input id="ud" name="description" maxLength={2000} />
      <Alert>{err}</Alert><Alert kind="ok">{msg}</Alert>
      <button className="btn primary" style={{ marginTop: 12 }} disabled={busy}>{busy ? "Uploading..." : "Upload"}</button>
    </form>
  );
}
