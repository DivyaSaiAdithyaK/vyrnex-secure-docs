export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export async function api<T>(url: string, init: RequestInit = {}): Promise<T> {
  const isForm = typeof FormData !== "undefined" && init.body instanceof FormData;
  const res = await fetch(url, { ...init, credentials: "same-origin", headers: isForm || !init.body ? init.headers : { "Content-Type": "application/json", ...init.headers } });
  let body: { error?: string } | null = null;
  try { body = await res.json(); } catch { /* non-JSON */ }
  if (!res.ok) throw new ApiError(res.status, body?.error ?? `Request failed (${res.status})`);
  return body as T;
}
export const fmtDate = (s: string | Date) => new Date(s).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
export const fmtSize = (n: number) => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(1)} MB`);
export const CATEGORIES = ["general", "contract", "salary", "legal", "finance", "hr", "engineering", "audit"];
export type Doc = { id: string; name: string; description: string; category: string; original_name: string; mime_type: string; size_bytes: number; created_at: string; updated_at: string; owner_name: string; owner_email: string; access: "owner" | "edit" | "read" };
