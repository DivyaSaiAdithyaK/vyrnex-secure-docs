import { currentUser } from "@/server/auth/session";
import { DocumentsView } from "@/components/DocumentsView";

export default async function Dashboard() {
  const user = await currentUser();
  return <DocumentsView role={user?.role ?? "viewer"} />;
}
