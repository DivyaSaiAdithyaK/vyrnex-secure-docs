import { redirect } from "next/navigation";
import { currentUser } from "@/server/auth/session";
import { Nav } from "@/components/Nav";

export const dynamic = "force-dynamic";
// UI convenience only. Every API route still authenticates and authorises on its own.
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await currentUser();
  if (!user) redirect("/login");
  return <><Nav user={{ name: user.name, role: user.role }} /><main><div className="wrap">{children}</div></main></>;
}
