import { DocumentDetail } from "@/components/DocumentDetail";

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  return <DocumentDetail id={(await params).id} />;
}
