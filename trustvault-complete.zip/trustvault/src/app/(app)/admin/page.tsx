import { redirect } from "next/navigation";
import { currentUser } from "@/server/auth/session";
import { AdminConsole } from "@/components/AdminConsole";

export default async function Admin() {
  const user = await currentUser();
  if (user?.role !== "admin") redirect("/dashboard");
  return <AdminConsole />;
}
