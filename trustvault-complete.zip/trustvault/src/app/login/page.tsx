"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { Alert } from "@/components/ui";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false); const [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try { await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }); router.push("/dashboard"); router.refresh(); }
    catch (err) { setError((err as Error).message); setBusy(false); }
  }
  return (
    <main className="wrap"><form className="card login" onSubmit={submit}>
      <div className="logo" style={{ marginBottom: 14 }}><i />TrustVault</div>
      <h1>Sign in</h1><p className="sub">Accounts are created by an administrator.</p>
      <Alert>{error}</Alert>
      <label htmlFor="email">Email</label><input id="email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
      <label htmlFor="pw">Password</label><input id="pw" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      <button className="btn primary" style={{ width: "100%", marginTop: 18 }} disabled={busy}>{busy ? "Signing in..." : "Sign in"}</button>
    </form></main>
  );
}
