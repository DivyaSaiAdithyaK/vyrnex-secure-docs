import { verifyChain } from "@/server/audit";
import { json, requireAdmin, route } from "@/server/http";

export const GET = route(async (req) => { await requireAdmin(req); return json(await verifyChain()); });
