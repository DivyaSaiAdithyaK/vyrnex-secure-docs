import { z } from "zod";
import { listAudit } from "@/server/audit";
import { json, requireAdmin, route } from "@/server/http";

const q = z.object({
  outcome: z.enum(["success", "denied", "error"]).optional(), action: z.string().max(40).optional(), q: z.string().max(100).optional(),
  documentId: z.uuid().optional(), before: z.coerce.number().int().positive().optional(), limit: z.coerce.number().int().min(1).max(200).default(50),
});

export const GET = route(async (req) => {
  await requireAdmin(req);
  const p = q.parse(Object.fromEntries([...new URL(req.url).searchParams.entries()].filter(([, v]) => v !== "")));
  return json({ events: await listAudit(p) });
});
