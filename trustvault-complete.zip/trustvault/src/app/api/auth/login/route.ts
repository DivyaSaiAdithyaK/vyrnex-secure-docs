import { z } from "zod";
import { sql } from "drizzle-orm";
import { db } from "@/server/db/client";
import { audit } from "@/server/audit";
import { DUMMY_HASH, verifyPassword } from "@/server/auth/password";
import { createSession } from "@/server/auth/session";
import { json, loginThrottled, requestMeta, route } from "@/server/http";

const body = z.object({ email: z.string().trim().toLowerCase().email().max(254), password: z.string().min(1).max(200) });

export const POST = route(async (req) => {
  const { email, password } = body.parse(await req.json().catch(() => null));
  const meta = requestMeta(req);
  if (await loginThrottled(email, meta.ip)) {
    await audit({ actorEmail: email, action: "auth.login", outcome: "denied", reason: "throttled", meta });
    return json({ error: "Too many failed attempts. Try again in 15 minutes." }, 429);
  }
  const r = await db.execute(sql`SELECT id, email, password_hash, disabled_at FROM users WHERE email = ${email}`);
  const u = r.rows[0] as { id: string; email: string; password_hash: string; disabled_at: Date | null } | undefined;
  // Always run one scrypt verification so unknown emails and wrong passwords take the same time.
  const ok = await verifyPassword(password, u?.password_hash ?? DUMMY_HASH);
  if (!u || !ok || u.disabled_at) {
    await audit({ actorEmail: email, action: "auth.login", outcome: "denied", reason: !u ? "unknown_user" : u.disabled_at ? "disabled" : "bad_password", meta });
    return json({ error: "Invalid email or password" }, 401);
  }
  await createSession(u.id);
  await audit({ actor: { id: u.id, email: u.email }, action: "auth.login", outcome: "success", meta });
  return json({ ok: true });
});
