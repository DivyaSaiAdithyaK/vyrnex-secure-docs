import { json, requireUser, route } from "@/server/http";

export const GET = route(async () => json({ user: await requireUser() }));
