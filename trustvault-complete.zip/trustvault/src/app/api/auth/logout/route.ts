import { audit } from "@/server/audit";
import { destroySession, currentUser } from "@/server/auth/session";
import { json, requestMeta, route } from "@/server/http";

export const POST = route(async (req) => {
  const u = await currentUser();
  await destroySession();
  if (u) await audit({ actor: u, action: "auth.logout", outcome: "success", meta: requestMeta(req) });
  return json({ ok: true });
});
