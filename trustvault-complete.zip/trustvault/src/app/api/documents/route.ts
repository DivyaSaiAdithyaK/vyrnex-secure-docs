import { createDocument, listDocuments } from "@/server/documents/service";
import { filterSchema, MAX_BYTES, metaSchema } from "@/server/documents/validation";
import { HttpError } from "@/server/errors";
import { json, requestMeta, requireUser, route } from "@/server/http";

export const GET = route(async (req) => {
  const user = await requireUser();
  const sp = new URL(req.url).searchParams;
  const f = filterSchema.parse(Object.fromEntries([...sp.entries()].filter(([, v]) => v !== "")));
  return json({ documents: await listDocuments(user, f) });
});

export const POST = route(async (req) => {
  const user = await requireUser();
  const meta = requestMeta(req);
  if (Number(req.headers.get("content-length") ?? 0) > MAX_BYTES + 100_000) throw new HttpError(413, "File is larger than 4 MB");
  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!form || !(file instanceof File)) throw new HttpError(400, "A file is required");
  const m = metaSchema.parse({ name: form.get("name") ?? undefined, description: form.get("description") ?? undefined, category: form.get("category") ?? undefined });
  const doc = await createDocument(user, meta, m, { originalName: file.name, bytes: Buffer.from(await file.arrayBuffer()) });
  return json({ document: { id: doc.id, name: doc.name } }, 201);
});
