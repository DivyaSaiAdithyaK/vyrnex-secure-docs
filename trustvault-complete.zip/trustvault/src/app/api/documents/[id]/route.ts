import { deleteDocument, getDocument, updateDocument } from "@/server/documents/service";
import { MAX_BYTES, patchSchema } from "@/server/documents/validation";
import { HttpError } from "@/server/errors";
import { idParam, json, requestMeta, requireUser, route } from "@/server/http";

type P = { id: string };

export const GET = route<P>(async (req, { params }) => {
  const user = await requireUser();
  return json(await getDocument(user, idParam((await params).id), requestMeta(req)));
});

export const PATCH = route<P>(async (req, { params }) => {
  const user = await requireUser();
  const id = idParam((await params).id);
  const meta = requestMeta(req);
  if ((req.headers.get("content-type") ?? "").startsWith("multipart/form-data")) {
    if (Number(req.headers.get("content-length") ?? 0) > MAX_BYTES + 100_000) throw new HttpError(413, "File is larger than 4 MB");
    const form = await req.formData();
    const raw: Record<string, unknown> = {};
    for (const k of ["name", "description", "category"]) { const v = form.get(k); if (typeof v === "string" && v !== "") raw[k] = v; }
    const f = form.get("file");
    const file = f instanceof File && f.size > 0 ? { originalName: f.name, bytes: Buffer.from(await f.arrayBuffer()) } : undefined;
    const doc = await updateDocument(user, id, meta, patchSchema.parse(raw), file);
    return json({ document: { id: doc.id, name: doc.name } });
  }
  const doc = await updateDocument(user, id, meta, patchSchema.parse(await req.json().catch(() => null)));
  return json({ document: { id: doc.id, name: doc.name } });
});

export const DELETE = route<P>(async (req, { params }) => {
  const user = await requireUser();
  await deleteDocument(user, idParam((await params).id), requestMeta(req));
  return json({ ok: true });
});
