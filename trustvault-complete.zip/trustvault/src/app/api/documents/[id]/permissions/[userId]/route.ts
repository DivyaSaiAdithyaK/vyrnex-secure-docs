import { revokePermission } from "@/server/documents/service";
import { idParam, json, requestMeta, requireUser, route } from "@/server/http";

export const DELETE = route<{ id: string; userId: string }>(async (req, { params }) => {
  const user = await requireUser();
  const p = await params;
  await revokePermission(user, idParam(p.id), requestMeta(req), idParam(p.userId));
  return json({ ok: true });
});
