import { grantPermission, listPermissions } from "@/server/documents/service";
import { grantSchema } from "@/server/documents/validation";
import { idParam, json, requestMeta, requireUser, route } from "@/server/http";

type P = { id: string };

export const GET = route<P>(async (req, { params }) => {
  const user = await requireUser();
  return json({ permissions: await listPermissions(user, idParam((await params).id), requestMeta(req)) });
});

export const POST = route<P>(async (req, { params }) => {
  const user = await requireUser();
  const g = grantSchema.parse(await req.json().catch(() => null));
  return json({ permission: await grantPermission(user, idParam((await params).id), requestMeta(req), g.email, g.level) }, 201);
});
