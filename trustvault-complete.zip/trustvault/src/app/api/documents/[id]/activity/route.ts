import { documentActivity } from "@/server/audit";
import { authorize } from "@/server/authz/authorize";
import { audit } from "@/server/audit";
import { notFound } from "@/server/errors";
import { idParam, json, requestMeta, requireUser, route } from "@/server/http";

// Owner-only: who touched THIS document, including refused attempts.
export const GET = route<{ id: string }>(async (req, { params }) => {
  const user = await requireUser();
  const id = idParam((await params).id);
  const d = await authorize(user, id, "share");
  if (!d.allowed) {
    await audit({ actor: user, action: "document.activity", outcome: "denied", reason: d.reason, documentId: id, documentName: d.docName, meta: requestMeta(req) });
    throw notFound();
  }
  return json({ events: await documentActivity(id) });
});
