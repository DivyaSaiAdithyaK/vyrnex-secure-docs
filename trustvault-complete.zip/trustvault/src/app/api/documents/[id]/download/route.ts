import { downloadDocument } from "@/server/documents/service";
import { idParam, requestMeta, requireUser, route } from "@/server/http";

// The ONLY way file bytes leave the system. No signed URLs, no share links.
export const GET = route<{ id: string }>(async (req, { params }) => {
  const user = await requireUser();
  const { doc, bytes } = await downloadDocument(user, idParam((await params).id), requestMeta(req));
  const ascii = doc.originalName.replace(/[^A-Za-z0-9._-]/g, "_");
  return new Response(new Uint8Array(bytes), {
    headers: {
      "Content-Type": doc.mimeType,
      "Content-Length": String(bytes.length),
      "Content-Disposition": `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(doc.originalName)}`,
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "sandbox; default-src 'none'",
      "Cache-Control": "no-store",
    },
  });
});
