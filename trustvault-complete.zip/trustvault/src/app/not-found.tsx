import Link from "next/link";
export default function NotFound() {
  return <div className="wrap"><div className="empty" style={{ paddingTop: 100 }}><h1>Page not found</h1><p><Link href="/">Back to TrustVault</Link></p></div></div>;
}
