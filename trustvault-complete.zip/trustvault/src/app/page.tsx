import Link from "next/link";
import { currentUser } from "@/server/auth/session";

export const dynamic = "force-dynamic";
const pillars = [
  ["The server decides, every time", "One authorisation function runs on every read, download, edit, delete and share. Unauthorised access looks exactly like a missing document."],
  ["Proof of who reached it", "Every upload, download, change, deletion, permission change and refused attempt is written to an append-only, hash-chained audit trail that can be verified."],
  ["Revocation is instant", "Access lives in one database row. Remove it and the next request fails. There are no share links or signed URLs to outlive it."],
];
export default async function Home() {
  const user = await currentUser();
  return (
    <>
      <header className="nav"><div className="wrap"><span className="logo"><i />TrustVault</span><span style={{ flex: 1 }} />
        <Link className="btn primary" href={user ? "/dashboard" : "/login"}>{user ? "Open dashboard" : "Sign in"}</Link></div></header>
      <main><div className="wrap">
        <section className="hero">
          <h1>Confidential documents.<br /><span>Provable access.</span></h1>
          <p>Share salary letters, contracts and audit papers with exactly the people you choose, and prove afterwards who opened them.</p>
          <Link className="btn primary" href={user ? "/dashboard" : "/login"}>{user ? "Open dashboard" : "Sign in to TrustVault"}</Link>
        </section>
        <section className="grid g3">{pillars.map(([t, d]) => <div className="card" key={t}><h2>{t}</h2><p className="sub" style={{ margin: 0 }}>{d}</p></div>)}</section>
      </div></main>
    </>
  );
}
