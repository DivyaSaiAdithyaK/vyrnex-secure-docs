import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "TrustVault: secure documents with proof of access", description: "Documents reachable only by people who were granted them, with a tamper-evident audit trail." };
export const viewport: Viewport = { width: "device-width", initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
