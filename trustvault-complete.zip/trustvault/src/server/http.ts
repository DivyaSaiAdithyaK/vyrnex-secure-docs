import { ZodError } from "zod";
import { sql } from "drizzle-orm";
import { db } from "@/server/db/client";
import { currentUser } from "@/server/auth/session";
import type { SessionUser } from "@/server/authz/authorize";
import type { Meta } from "@/server/audit";
import { HttpError } from "@/server/errors";

export const json = (data: unknown, status = 200) =>
  Response.json(data, { status, headers: { "Cache-Control": "no-store" } });

export function requestMeta(req: Request): Meta {
  const h = req.headers;
  const ip = h.get("x-vercel-forwarded-for") ?? h.get("x-real-ip") ?? h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
  return { ip: ip?.slice(0, 64) ?? null, userAgent: h.get("user-agent") };
}

/** CSRF defence in depth (cookies are also SameSite=Lax): a mutating request must come from our own origin. */
function assertSameOrigin(req: Request) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return;
  const origin = req.headers.get("origin");
  const host = req.headers.get("host");
  if (origin) {
    let ok = false;
    try { ok = new URL(origin).host === host; } catch { /* malformed */ }
    if (!ok) throw new HttpError(403, "Cross-origin request blocked");
  } else if (req.headers.get("sec-fetch-site") && req.headers.get("sec-fetch-site") !== "same-origin") {
    throw new HttpError(403, "Cross-origin request blocked");
  }
}

export async function requireUser(): Promise<SessionUser> {
  const u = await currentUser();
  if (!u) throw new HttpError(401, "Not signed in");
  return u;
}
export async function requireAdmin(req: Request): Promise<SessionUser> {
  const u = await requireUser();
  if (u.role !== "admin") {
    const { audit } = await import("@/server/audit");
    await audit({ actor: u, action: "admin.access", outcome: "denied", reason: "not_admin", meta: requestMeta(req), details: { path: new URL(req.url).pathname } });
    throw new HttpError(403, "Administrators only");
  }
  return u;
}

type Handler<P> = (req: Request, ctx: { params: Promise<P> }) => Promise<Response>;
export function route<P = Record<string, never>>(h: Handler<P>): Handler<P> {
  return async (req, ctx) => {
    try {
      assertSameOrigin(req);
      return await h(req, ctx);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      if (e instanceof ZodError) return json({ error: "Invalid input", issues: e.issues.map((i) => ({ path: i.path.join("."), message: i.message })) }, 400);
      console.error("Unhandled error:", e instanceof Error ? e.message : "unknown"); // never log request bodies
      return json({ error: "Internal server error" }, 500);
    }
  };
}

export const idParam = (v: string) => {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)) throw new HttpError(404, "Document not found");
  return v.toLowerCase();
};

/** Failed-login throttle backed by the audit table itself (works across serverless instances). */
export async function loginThrottled(email: string, ip: string | null) {
  const r = await db.execute(sql`
    SELECT count(*) FILTER (WHERE actor_email = ${email}) AS by_email, count(*) FILTER (WHERE ip = ${ip}) AS by_ip
    FROM audit_events WHERE action = 'auth.login' AND outcome <> 'success' AND at > now() - interval '15 minutes'`);
  const x = (r.rows[0] ?? {}) as { by_email?: string; by_ip?: string };
  return Number(x.by_email ?? 0) >= 5 || (ip !== null && Number(x.by_ip ?? 0) >= 30);
}
