import { sql } from "drizzle-orm";
import { db } from "@/server/db/client";

// The ONLY module that writes to audit_events. seq, time, prev_hash and hash are assigned by a
// database trigger; the placeholder values below are ignored (and tested to be ignored).
export type Db = Pick<typeof db, "execute">;
export type Meta = { ip: string | null; userAgent: string | null };
export type AuditInput = {
  actor?: { id: string; email: string } | null;
  actorEmail?: string | null; // for failed logins where there is no user yet
  action: string;
  outcome: "success" | "denied" | "error";
  reason?: string;
  documentId?: string | null;
  documentName?: string | null;
  targetUserId?: string | null;
  meta?: Meta;
  details?: Record<string, unknown>; // never put passwords, tokens or file contents here
};

export async function audit(e: AuditInput, d: Db = db): Promise<void> {
  await d.execute(sql`
    INSERT INTO audit_events (seq, prev_hash, hash, actor_id, actor_email, action, outcome, reason,
      document_id, document_name, target_user_id, ip, user_agent, details)
    VALUES (0, '', '', ${e.actor?.id ?? null}, ${e.actor?.email ?? e.actorEmail ?? null}, ${e.action}, ${e.outcome},
      ${e.reason ?? null}, ${e.documentId ?? null}, ${e.documentName ?? null}, ${e.targetUserId ?? null},
      ${e.meta?.ip ?? null}, ${e.meta?.userAgent?.slice(0, 300) ?? null}, ${JSON.stringify(e.details ?? {})}::jsonb)`);
}

export type AuditFilters = { outcome?: string; action?: string; q?: string; documentId?: string; before?: number; limit: number };
const esc = (s: string) => s.replace(/[\\%_]/g, "\\$&");

export async function listAudit(f: AuditFilters) {
  const c = [sql`true`];
  if (f.outcome) c.push(sql`outcome = ${f.outcome}`);
  if (f.action) c.push(sql`action LIKE ${esc(f.action) + "%"}`);
  if (f.q) c.push(sql`(actor_email ILIKE ${"%" + esc(f.q) + "%"} OR document_name ILIKE ${"%" + esc(f.q) + "%"})`);
  if (f.documentId) c.push(sql`document_id = ${f.documentId}`);
  if (f.before) c.push(sql`seq < ${f.before}`);
  const r = await db.execute(sql`
    SELECT seq, at, actor_email, action, outcome, reason, document_id, document_name, ip, details, hash
    FROM audit_events WHERE ${sql.join(c, sql` AND `)} ORDER BY seq DESC LIMIT ${f.limit}`);
  return (r.rows as Record<string, unknown>[]).map((x) => ({ ...x, seq: Number(x.seq) }));
}

export async function documentActivity(documentId: string, limit = 50) {
  const r = await db.execute(sql`
    SELECT seq, at, actor_email, action, outcome, reason, ip FROM audit_events
    WHERE document_id = ${documentId} ORDER BY seq DESC LIMIT ${limit}`);
  return (r.rows as Record<string, unknown>[]).map((x) => ({ ...x, seq: Number(x.seq) }));
}

export async function verifyChain() {
  const r = await db.execute(sql`SELECT * FROM verify_audit_chain()`);
  const v = (r.rows[0] ?? {}) as { ok?: boolean; broken_seq?: string | null; checked?: string; head_hash?: string | null };
  return { ok: !!v.ok, brokenSeq: v.broken_seq ? Number(v.broken_seq) : null, checked: Number(v.checked ?? 0), headHash: v.head_hash ?? null };
}

export async function auditStats() {
  const r = await db.execute(sql`
    SELECT (SELECT count(*) FROM audit_events) AS events,
           (SELECT count(*) FROM audit_events WHERE outcome <> 'success' AND at > now() - interval '24 hours') AS refused_24h,
           (SELECT count(*) FROM audit_events WHERE action = 'document.download' AND outcome = 'success' AND at > now() - interval '24 hours') AS downloads_24h,
           (SELECT count(*) FROM audit_events WHERE action LIKE 'permission.%' AND outcome = 'success' AND at > now() - interval '24 hours') AS permission_changes_24h,
           (SELECT count(*) FROM documents) AS documents, (SELECT count(*) FROM users) AS users`);
  const x = (r.rows[0] ?? {}) as Record<string, string>;
  return Object.fromEntries(Object.entries(x).map(([k, v]) => [k, Number(v)]));
}
