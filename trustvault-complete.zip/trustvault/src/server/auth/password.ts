import { randomBytes, scrypt, timingSafeEqual, type ScryptOptions } from "node:crypto";

// scrypt N=2^16, r=8, p=1 (OWASP-recommended minimum class). Built into Node: no native module on Vercel.
const N = 65536, R = 8, P = 1, KEYLEN = 64;
const OPTS: ScryptOptions = { N, r: R, p: P, maxmem: 160 * 1024 * 1024 };

function derive(password: string, salt: Buffer, opts: ScryptOptions = OPTS, keylen = KEYLEN): Promise<Buffer> {
  return new Promise((res, rej) => scrypt(password.normalize("NFKC"), salt, keylen, opts, (e, k) => (e ? rej(e) : res(k))));
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await derive(password, salt);
  return ["scrypt", N, R, P, salt.toString("base64"), key.toString("base64")].join("$");
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [alg, n, r, p, salt, key] = stored.split("$");
  if (alg !== "scrypt" || !salt || !key) return false;
  const expected = Buffer.from(key, "base64");
  const actual = await derive(password, Buffer.from(salt, "base64"),
    { N: Number(n), r: Number(r), p: Number(p), maxmem: 160 * 1024 * 1024 }, expected.length);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

// Verify against this when the email is unknown, so "no such user" costs the same time as "wrong password".
export const DUMMY_HASH = "scrypt$65536$8$1$AAAAAAAAAAAAAAAAAAAAAA==$" + Buffer.alloc(KEYLEN).toString("base64");
