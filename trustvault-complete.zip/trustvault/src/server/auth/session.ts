import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { sql } from "drizzle-orm";
import { db } from "@/server/db/client";
import type { SessionUser } from "@/server/authz/authorize";

export const COOKIE = "tv_session";
const TTL_MS = 8 * 60 * 60 * 1000;
const hashToken = (t: string) => createHash("sha256").update(t).digest("hex");

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + TTL_MS);
  await db.execute(sql`INSERT INTO sessions (user_id, token_hash, expires_at) VALUES (${userId}, ${hashToken(token)}, ${expires.toISOString()})`);
  (await cookies()).set(COOKIE, token, {
    httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", expires,
  });
}

/** Re-checked against the database on EVERY request: disabling a user or deleting a session works instantly. */
export async function currentUser(): Promise<SessionUser | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token || token.length > 100) return null;
  const r = await db.execute(sql`
    SELECT u.id, u.email, u.name, u.role FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ${hashToken(token)} AND s.expires_at > now() AND u.disabled_at IS NULL`);
  return (r.rows[0] as SessionUser | undefined) ?? null;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (token) await db.execute(sql`DELETE FROM sessions WHERE token_hash = ${hashToken(token)}`);
  jar.delete(COOKIE);
}
