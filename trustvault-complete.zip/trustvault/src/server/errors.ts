export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
/** Same response for "does not exist" and "not allowed", so existence is never revealed. */
export const notFound = () => new HttpError(404, "Document not found");
