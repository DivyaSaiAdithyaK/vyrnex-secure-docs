import { z } from "zod";
import { createHash } from "node:crypto";
import { HttpError } from "@/server/errors";

export const CATEGORIES = ["general", "contract", "salary", "legal", "finance", "hr", "engineering", "audit"] as const;
export const MAX_BYTES = 4 * 1024 * 1024; // under Vercel's 4.5 MB request limit

export const metaSchema = z.object({
  name: z.string().trim().min(1).max(200),
  description: z.string().trim().max(2000).default(""),
  category: z.enum(CATEGORIES).default("general"),
});
export const patchSchema = metaSchema.partial();
export const grantSchema = z.object({ email: z.string().trim().toLowerCase().email().max(254), level: z.enum(["read", "edit"]) });
const day = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
export const filterSchema = z.object({
  q: z.string().trim().max(100).optional(), owner: z.string().trim().max(100).optional(),
  category: z.enum(CATEGORIES).optional(), from: day.optional(), to: day.optional(),
});

// Type is decided from the extension AND the file's real leading bytes. The client-supplied MIME type is ignored.
const TYPES: Record<string, { mime: string; magic?: number[]; text?: boolean }> = {
  pdf: { mime: "application/pdf", magic: [0x25, 0x50, 0x44, 0x46, 0x2d] },
  png: { mime: "image/png", magic: [0x89, 0x50, 0x4e, 0x47] },
  jpg: { mime: "image/jpeg", magic: [0xff, 0xd8, 0xff] },
  jpeg: { mime: "image/jpeg", magic: [0xff, 0xd8, 0xff] },
  docx: { mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", magic: [0x50, 0x4b, 3, 4] },
  xlsx: { mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", magic: [0x50, 0x4b, 3, 4] },
  pptx: { mime: "application/vnd.openxmlformats-officedocument.presentationml.presentation", magic: [0x50, 0x4b, 3, 4] },
  txt: { mime: "text/plain", text: true },
  csv: { mime: "text/csv", text: true },
};
export const ALLOWED_EXTENSIONS = Object.keys(TYPES);

export function cleanFilename(raw: string) {
  const base = raw.split(/[\\/]/).pop() ?? "";
  return base.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, 150);
}

export function validateUpload(originalName: string, bytes: Buffer) {
  const name = cleanFilename(originalName);
  const ext = name.includes(".") ? name.split(".").pop()!.toLowerCase() : "";
  const t = TYPES[ext];
  if (!name || !t) throw new HttpError(400, `File type not allowed. Allowed: ${ALLOWED_EXTENSIONS.join(", ")}`);
  if (bytes.length === 0) throw new HttpError(400, "File is empty");
  if (bytes.length > MAX_BYTES) throw new HttpError(400, "File is larger than 4 MB");
  if (t.magic && !t.magic.every((b, i) => bytes[i] === b)) throw new HttpError(400, "File content does not match its extension");
  if (t.text) {
    if (bytes.includes(0)) throw new HttpError(400, "Text file contains binary data");
    try { new TextDecoder("utf-8", { fatal: true }).decode(bytes); } catch { throw new HttpError(400, "Text file is not valid UTF-8"); }
  }
  return { originalName: name, mime: t.mime, size: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") };
}
