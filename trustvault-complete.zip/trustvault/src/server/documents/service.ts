import { and, eq, sql } from "drizzle-orm";
import { db } from "@/server/db/client";
import { documentFiles, documents, permissions, users } from "@/server/db/schema";
import { audit, type Meta } from "@/server/audit";
import { authorize, type Action, type SessionUser } from "@/server/authz/authorize";
import { HttpError, notFound } from "@/server/errors";
import { validateUpload } from "./validation";

type Meta2 = { name: string; description: string; category: string };
type FileIn = { originalName: string; bytes: Buffer };
const esc = (s: string) => s.replace(/[\\%_]/g, "\\$&");

/** authenticate (done by caller) -> authorize -> audit refusal. Refusals look identical to "does not exist". */
async function gate(user: SessionUser, id: string, action: Action, meta: Meta) {
  const d = await authorize(user, id, action);
  if (!d.allowed) {
    await audit({ actor: user, action: `document.${action}`, outcome: "denied", reason: d.reason, documentId: id, documentName: d.docName, meta });
    throw notFound();
  }
  return d;
}

export async function listDocuments(user: SessionUser, f: { q?: string; owner?: string; category?: string; from?: string; to?: string }) {
  const c = [sql`(d.owner_id = ${user.id} OR p.user_id IS NOT NULL)`]; // visibility rule, mirrors authorize()
  if (f.q) { const p = `%${esc(f.q)}%`; c.push(sql`(d.name ILIKE ${p} OR d.original_name ILIKE ${p} OR d.description ILIKE ${p})`); }
  if (f.owner) { const p = `%${esc(f.owner)}%`; c.push(sql`(u.name ILIKE ${p} OR u.email ILIKE ${p})`); }
  if (f.category) c.push(sql`d.category = ${f.category}`);
  if (f.from) c.push(sql`d.created_at >= ${f.from}::date`);
  if (f.to) c.push(sql`d.created_at < (${f.to}::date + 1)`);
  const r = await db.execute(sql`
    SELECT d.id, d.name, d.description, d.category, d.original_name, d.mime_type, d.size_bytes, d.created_at, d.updated_at,
      u.name AS owner_name, u.email AS owner_email,
      CASE WHEN d.owner_id = ${user.id} THEN 'owner' ELSE p.level::text END AS access
    FROM documents d JOIN users u ON u.id = d.owner_id
    LEFT JOIN permissions p ON p.document_id = d.id AND p.user_id = ${user.id}
    WHERE ${sql.join(c, sql` AND `)} ORDER BY d.created_at DESC LIMIT 200`);
  return r.rows;
}

export async function getDocument(user: SessionUser, id: string, meta: Meta) {
  const d = await gate(user, id, "read", meta);
  await audit({ actor: user, action: "document.view", outcome: "success", documentId: id, documentName: d.docName, meta });
  const [o] = await db.select({ name: users.name, email: users.email }).from(users).where(eq(users.id, d.doc.ownerId));
  const { ...doc } = d.doc;
  return { document: { ...doc, ownerName: o?.name ?? "", ownerEmail: o?.email ?? "" }, access: d.access,
    can: { edit: d.access !== "read", share: d.access === "owner", delete: d.access === "owner" } };
}

export async function createDocument(user: SessionUser, meta: Meta, m: Meta2, file: FileIn) {
  if (user.role !== "owner") {
    await audit({ actor: user, action: "document.upload", outcome: "denied", reason: "role_cannot_upload", documentName: m.name, meta });
    throw new HttpError(403, "Your role cannot upload documents");
  }
  let v;
  try { v = validateUpload(file.originalName, file.bytes); }
  catch (e) {
    await audit({ actor: user, action: "document.upload", outcome: "denied", reason: "validation_failed", documentName: m.name, meta, details: { why: (e as Error).message } });
    throw e;
  }
  return db.transaction(async (tx) => {
    const [doc] = await tx.insert(documents).values({ ownerId: user.id, name: m.name, description: m.description, category: m.category,
      originalName: v.originalName, mimeType: v.mime, sizeBytes: v.size, sha256: v.sha256 }).returning();
    if (!doc) throw new Error("insert failed");
    await tx.insert(documentFiles).values({ documentId: doc.id, content: file.bytes });
    await audit({ actor: user, action: "document.upload", outcome: "success", documentId: doc.id, documentName: doc.name, meta,
      details: { sizeBytes: v.size, sha256: v.sha256, mime: v.mime } }, tx);
    return doc;
  });
}

export async function updateDocument(user: SessionUser, id: string, meta: Meta, patch: Partial<Meta2>, file?: FileIn) {
  const d = await gate(user, id, "edit", meta);
  let v: ReturnType<typeof validateUpload> | null = null;
  if (file) {
    try { v = validateUpload(file.originalName, file.bytes); }
    catch (e) {
      await audit({ actor: user, action: "document.update", outcome: "denied", reason: "validation_failed", documentId: id, documentName: d.docName, meta, details: { why: (e as Error).message } });
      throw e;
    }
  }
  return db.transaction(async (tx) => {
    const set: Partial<typeof documents.$inferInsert> = { updatedAt: new Date() };
    if (patch.name !== undefined) set.name = patch.name;
    if (patch.description !== undefined) set.description = patch.description;
    if (patch.category !== undefined) set.category = patch.category;
    if (v) Object.assign(set, { originalName: v.originalName, mimeType: v.mime, sizeBytes: v.size, sha256: v.sha256 });
    const [doc] = await tx.update(documents).set(set).where(eq(documents.id, id)).returning();
    if (!doc) throw notFound();
    if (file) await tx.update(documentFiles).set({ content: file.bytes }).where(eq(documentFiles.documentId, id));
    await audit({ actor: user, action: "document.update", outcome: "success", documentId: id, documentName: doc.name, meta,
      details: { fields: Object.keys(patch), contentReplaced: !!file, previousName: d.docName, ...(v ? { sha256: v.sha256 } : {}) } }, tx);
    return doc;
  });
}

export async function deleteDocument(user: SessionUser, id: string, meta: Meta) {
  const d = await gate(user, id, "delete", meta);
  await db.transaction(async (tx) => {
    await tx.delete(documents).where(eq(documents.id, id)); // files + permissions cascade
    await audit({ actor: user, action: "document.delete", outcome: "success", documentId: id, documentName: d.docName, meta,
      details: { sha256: d.doc.sha256 } }, tx);
  });
}

export async function downloadDocument(user: SessionUser, id: string, meta: Meta) {
  const d = await gate(user, id, "download", meta);
  // Audit BEFORE any bytes are released: if the audit write fails, nothing is served.
  await audit({ actor: user, action: "document.download", outcome: "success", documentId: id, documentName: d.docName, meta, details: { sha256: d.doc.sha256 } });
  const [f] = await db.select({ content: documentFiles.content }).from(documentFiles).where(eq(documentFiles.documentId, id));
  if (!f) throw notFound();
  return { doc: d.doc, bytes: f.content };
}

export async function listPermissions(user: SessionUser, id: string, meta: Meta) {
  await gate(user, id, "share", meta);
  const r = await db.execute(sql`
    SELECT p.user_id, u.name, u.email, p.level, p.created_at FROM permissions p JOIN users u ON u.id = p.user_id
    WHERE p.document_id = ${id} ORDER BY p.created_at`);
  return r.rows;
}

export async function grantPermission(user: SessionUser, id: string, meta: Meta, email: string, level: "read" | "edit") {
  const d = await gate(user, id, "share", meta);
  const [target] = await db.select({ id: users.id, email: users.email, name: users.name }).from(users)
    .where(and(eq(users.email, email), sql`${users.disabledAt} IS NULL`));
  if (!target) throw new HttpError(404, "No active user with that email");
  if (target.id === user.id) throw new HttpError(400, "You already own this document");
  return db.transaction(async (tx) => {
    const [prev] = await tx.select({ level: permissions.level }).from(permissions)
      .where(and(eq(permissions.documentId, id), eq(permissions.userId, target.id)));
    await tx.insert(permissions).values({ documentId: id, userId: target.id, level, grantedBy: user.id })
      .onConflictDoUpdate({ target: [permissions.documentId, permissions.userId], set: { level, grantedBy: user.id } });
    await audit({ actor: user, action: prev ? "permission.update" : "permission.grant", outcome: "success", documentId: id, documentName: d.docName,
      targetUserId: target.id, meta, details: { targetEmail: target.email, level, previousLevel: prev?.level ?? null } }, tx);
    return { userId: target.id, name: target.name, email: target.email, level };
  });
}

export async function revokePermission(user: SessionUser, id: string, meta: Meta, targetUserId: string) {
  const d = await gate(user, id, "share", meta);
  await db.transaction(async (tx) => {
    const del = await tx.delete(permissions).where(and(eq(permissions.documentId, id), eq(permissions.userId, targetUserId))).returning();
    if (del.length === 0) throw new HttpError(404, "That user has no access to revoke");
    await audit({ actor: user, action: "permission.revoke", outcome: "success", documentId: id, documentName: d.docName,
      targetUserId, meta, details: { previousLevel: del[0]?.level } }, tx);
  });
}
