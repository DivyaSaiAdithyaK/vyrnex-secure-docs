import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import * as schema from "./schema";

const url = process.env.DATABASE_URL;
if (!url) throw new Error("DATABASE_URL is not set");

// Small pool: serverless instances multiply, and Neon limits connections.
export const pool = new Pool({ connectionString: url, max: 5 });
export const db = drizzle(pool, { schema });
