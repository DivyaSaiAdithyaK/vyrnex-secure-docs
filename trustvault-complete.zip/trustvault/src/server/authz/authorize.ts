import { and, eq } from "drizzle-orm";
import { db } from "@/server/db/client";
import { documents, permissions } from "@/server/db/schema";

export type Role = "admin" | "owner" | "viewer";
export type SessionUser = { id: string; email: string; name: string; role: Role };
export type Action = "read" | "download" | "edit" | "delete" | "share";
export type Access = "owner" | "edit" | "read";
type Doc = typeof documents.$inferSelect;
export type Decision =
  | { allowed: true; reason: "ok"; doc: Doc; access: Access; docName: string }
  | { allowed: false; reason: "not_found" | "no_grant" | "insufficient_level"; doc: null; access: null; docName: string | null };

// Who may do what, per access level. The admin ROLE grants NO document access: admins see activity, not content.
const NEED: Record<Action, Access[]> = {
  read: ["owner", "edit", "read"],
  download: ["owner", "edit", "read"],
  edit: ["owner", "edit"],
  delete: ["owner"],
  share: ["owner"],
};

/**
 * THE single authorisation decision for any document operation.
 * Reads the document and the grant from the database on every call: nothing is cached,
 * so revoking a grant takes effect on the very next request.
 */
export async function authorize(user: SessionUser, documentId: string, action: Action): Promise<Decision> {
  const [doc] = await db.select().from(documents).where(eq(documents.id, documentId)).limit(1);
  if (!doc) return { allowed: false, reason: "not_found", doc: null, access: null, docName: null };
  let access: Access | null = null;
  if (doc.ownerId === user.id) access = "owner";
  else {
    const [g] = await db.select({ level: permissions.level }).from(permissions)
      .where(and(eq(permissions.documentId, doc.id), eq(permissions.userId, user.id))).limit(1);
    if (g) access = g.level;
  }
  if (!access) return { allowed: false, reason: "no_grant", doc: null, access: null, docName: doc.name };
  if (!NEED[action].includes(access)) return { allowed: false, reason: "insufficient_level", doc: null, access: null, docName: doc.name };
  return { allowed: true, reason: "ok", doc, access, docName: doc.name };
}
