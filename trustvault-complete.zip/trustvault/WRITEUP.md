# Write-up (DRAFT: edit so it is true and in your own words)

**What was built:** authentication with admin/owner/viewer roles; upload, edit, delete, search/filter by name, owner, category and date; per-document
read/edit grants to named users with immediate revocation; hash-chained audit of uploads, downloads, views, edits, deletions, permission changes and
refused attempts; an admin console (activity, filters, chain verification); integration tests against a real Postgres.

**Deliberately not built:** user management UI, password change, MFA, file versioning, malware scanning, object storage (files are bytea in Postgres),
an external anchor for the audit chain head, and AI features (the spec says AI must never widen access, so none was added).

**Permission model:** see README. Admin sees activity, never contents. Only owners upload, share and delete; `edit` grantees can change metadata/content.

**How AI was used and where it was wrong:** *write this yourself from PROMPTS.md.* Entry 1 (trigger-only audit) is real. Entries 2-5 are still PENDING:
do not fill them with anything that did not happen. After you run the build and tests, the errors they report are genuine candidates.

**Unfinished / unverified:** see README "Verification status" and THREATS.md rows marked Open/Accepted.
