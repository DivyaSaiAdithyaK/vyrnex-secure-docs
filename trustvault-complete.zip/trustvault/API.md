# API reference
All endpoints return JSON (errors: `{ "error": "..." }`) except download. Session cookie `tv_session` (HttpOnly, SameSite=Lax, 8 h).
Mutating requests must be same-origin. "Document ops" return **404** when you lack access, identical to a nonexistent id.

| Method & path | Who may call | Notes |
|---|---|---|
| POST `/api/auth/login` | anyone | `{email,password}`. 5 failures/email or 30/IP per 15 min -> 429. All attempts audited. |
| POST `/api/auth/logout` | signed-in | Deletes the session row. |
| GET `/api/auth/me` | signed-in | Current user. |
| GET `/api/documents` | signed-in | Only documents you own or were granted. Filters: `q`, `owner`, `category`, `from`, `to` (YYYY-MM-DD). |
| POST `/api/documents` | role `owner` | multipart: `file`, `name`, `category`, `description`. Type/size/magic-byte validated. |
| GET `/api/documents/:id` | owner, or any grant | Metadata + your access level. Audited as `document.view`. |
| PATCH `/api/documents/:id` | owner, or `edit` grant | JSON or multipart (optional replacement `file`). |
| DELETE `/api/documents/:id` | owner only | Cascades files and grants; audit history kept. |
| GET `/api/documents/:id/download` | owner, or any grant | Audited before bytes are sent. `attachment`, `nosniff`, `no-store`. |
| GET `/api/documents/:id/permissions` | owner only | |
| POST `/api/documents/:id/permissions` | owner only | `{email, level: read\|edit}`; upsert. |
| DELETE `/api/documents/:id/permissions/:userId` | owner only | Immediate. |
| GET `/api/documents/:id/activity` | owner only | Audit events for this document. |
| GET `/api/admin/audit` | admin only | Filters: `outcome`, `action` (prefix), `q`, `documentId`, `before`, `limit`. |
| GET `/api/admin/audit/verify` | admin only | Recomputes the hash chain. |
| GET `/api/admin/stats` | admin only | Counters. Non-admin attempts are audited as `admin.access` denied. |
