# TrustVault

Confidential documents that only the people you choose can reach, with a tamper-evident record of who reached them.
Next.js 15 (App Router) · TypeScript · PostgreSQL · Drizzle ORM · Zod. No third-party auth or storage services.

> **Status honesty:** see [Verification status](#verification-status) before relying on anything here.

## Roles (permission model)
| | admin | owner | viewer |
|---|---|---|---|
| Upload documents | no | yes | no |
| See / download a document | only if granted | own + granted | only if granted |
| Edit | only with `edit` grant | own + `edit` grant | only with `edit` grant |
| Delete, share, revoke, see per-document activity | no | own documents only | no |
| Global audit log, chain verification, stats | **yes** | no | no |

Access to a *document* comes only from ownership or a per-document grant (`read` or `edit`) to a named user. The admin role
deliberately grants **no** document access: admins see *activity*, not *contents*. Accounts are created by seeding (no public sign-up).

## How the three non-negotiables are met
1. **Only the granted can reach a document.** `src/server/authz/authorize.ts` is the single decision point, called by every
   document operation, reading the database fresh each time. Refusals return the same 404 as "does not exist". Files stream only
   through `GET /api/documents/:id/download`; there are no share links or signed URLs.
2. **Provable who reached it.** `audit_events` is hash-chained and append-only (DB triggers). The database assigns sequence, time and hash.
   `verify_audit_chain()` detects edits even by someone who disables the triggers. Refused attempts, failed logins and validation
   failures are recorded. Downloads are audited *before* bytes are released.
3. **Revocation is immediate.** A grant is one row; revoke deletes it. No caching. Sessions are checked against the DB per request.

## Setup
```bash
npm install
cp .env.example .env.local        # fill in DATABASE_URL and DATABASE_URL_TEST
npm run db:migrate                # applies sql/*.sql
npm run db:seed                   # 5 demo users (one per role + a second owner/viewer); prints generated passwords once
npm run dev                       # http://localhost:3000
```
Demo accounts: `admin@trustvault.demo`, `owner@trustvault.demo`, `owner2@trustvault.demo`, `viewer@trustvault.demo`, `viewer2@trustvault.demo`.
Set `SEED_PASSWORD_ADMIN/OWNER/VIEWER` to choose passwords; otherwise they are generated. Put the ones you choose in the README of your submission.

## Commands
`npm run typecheck` · `npm test` (needs `DATABASE_URL_TEST`; wipes that database) · `npm run build` · `npm start`

## Deploying (Vercel + Neon, free tiers)
1. Create a Neon project, copy its connection string (include `?sslmode=require`).
2. Locally: `DATABASE_URL=<neon url> npm run db:migrate && DATABASE_URL=<neon url> SEED_PASSWORD_ADMIN=... SEED_PASSWORD_OWNER=... SEED_PASSWORD_VIEWER=... npm run db:seed`.
3. Import the repo in Vercel; add the single env var `DATABASE_URL`. Deploy. Deploy early.
4. Also works on Render/Railway/Fly (`npm run build` then `npm start`).
Do **not** set `DATABASE_URL_TEST` on the hosting platform.

## Documentation
[API.md](API.md) (who may call each endpoint) · [THREATS.md](THREATS.md) · [PROMPTS.md](PROMPTS.md) · [WRITEUP.md](WRITEUP.md)

## Verification status
This code was written in an environment with no network access and no PostgreSQL, so **`npm install`, `tsc`, `next build` and the tests
were NOT run by the author of this version.** Run `npm install && npm run typecheck && npm test && npm run build` and fix anything they report
before submitting. The earlier audit test (`tests/integration/audit-db.test.ts`) was run by you previously per PROMPTS.md.
