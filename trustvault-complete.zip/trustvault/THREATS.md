# THREATS.md: how I think TrustVault could be broken

Status column: **Closed** = a control exists in code; **Accepted** = known weakness, reason given; **Open** = not done.
"Test" names a test that is *written*; it had not been executed when this file was drafted (see README, Verification status).
Re-check every row against the running system and delete or correct any claim you cannot reproduce.

| # | Attack | Control / reality | Status | Test |
|---|---|---|---|---|
| 1 | Guess or enumerate document ids (IDOR) on view, download, edit, delete, share, revoke | Every operation calls `authorize()`, which reads owner + grant from the DB. Ids are random UUIDs but secrecy of ids is not relied on. | Closed | access-control: "refused on EVERY operation" |
| 2 | Tell whether a document exists from the error | Unauthorised and nonexistent both return 404 "Document not found". Malformed ids also 404. | Closed | same test (missing vs forbidden) |
| 3 | See documents via list or search | List/search SQL only returns rows the caller owns or holds a grant for; filters are ANDed onto that rule. | Closed | "never appears in list or search" |
| 4 | Use a revoked grant | Grant is a DB row, deleted on revoke; no cache or token. | Closed | "revoking works on the very next request" |
| 5 | Admin reads contents | Admin role has no document access by design. | Closed | "administrator has no document access" |
| 6 | Viewer/grantee escalates (edit, delete, re-share) | `NEED` table in `authorize.ts`; delete/share are owner-only. | Closed | read-grant and edit-grant tests |
| 7 | Hit API directly, skipping the UI | UI checks are cosmetic; each route authenticates and authorises. | Closed | covered via service tests (routes are thin) |
| 8 | Edit/delete audit rows (app or SQL) | Append-only triggers; app role cannot set seq/hash (trigger overwrites). | Closed vs app | audit-db.test.ts |
| 9 | Edit audit rows as DB superuser / table owner (disable triggers) | Hash chain + `verify_audit_chain()` detects the edit at the first altered row. | Detected, not prevented | audit-db.test.ts |
| 10 | Delete the **newest** audit rows | Chain stays valid. Admin page shows the head hash so it can be recorded off-database and compared. | **Accepted / partial**: needs an external anchor that I have not built | none |
| 11 | Rewrite the whole chain (recompute all hashes) as superuser | Hashes are unkeyed SHA-256, so a full recompute is undetectable without an external anchor. | **Accepted**, same fix as #10 | none |
| 12 | Brute-force passwords | scrypt N=2^16; failures/email (5) and failures/IP (30) per 15 min -> 429, throttle state lives in the audit table. | Closed (mitigated) | none |
| 13 | Lock a victim out by failing logins for their email | Side effect of #12. | Accepted | none |
| 14 | Learn which emails have accounts from login | Same message and equal scrypt work for unknown email / wrong password / disabled user. | Closed | none |
| 15 | Learn which emails have accounts via "grant access" | Owner-only endpoint returns "No active user with that email". | Accepted (needs a login to reach) | none |
| 16 | CSRF | SameSite=Lax cookie + Origin / Sec-Fetch-Site check on every mutating request. | Closed | none |
| 17 | Steal session token from DB leak | Only SHA-256 of the token is stored; cookie is HttpOnly and Secure in production. | Closed | none |
| 18 | SQL injection | Drizzle / parameterised `sql` templates everywhere; LIKE wildcards escaped; ids regex-checked. | Closed | none |
| 19 | Malicious upload (exe renamed .pdf, HTML/SVG, oversize, path traversal in name) | Extension allow-list + magic bytes + size cap; MIME derived server-side; name stripped of path/control chars; served as `attachment` with `nosniff` and `sandbox` CSP. | Closed (not malware scanning) | upload validation tests |
| 20 | Stored XSS via names/descriptions | React escapes output; no `dangerouslySetInnerHTML`. | Closed | none |
| 21 | Spoof client IP in the audit log | Uses platform header first (`x-vercel-forwarded-for`), but off-Vercel `X-Forwarded-For` is client-controlled. | Accepted | none |
| 22 | Secrets in logs/audit | Audit `details` carry hashes, sizes, levels only; error logging prints message only. Login failures log the attempted *email* (validated as an email, so not a password typed into the wrong box). | Closed | "never stores file contents" |
| 23 | Large uploads exhaust memory/DB | 4 MB cap checked on Content-Length and again on bytes. Files live in Postgres (bytea): fine for a demo, not for scale. | Accepted | none |
| 24 | Audit write contention | One global advisory lock serialises audit inserts (correct chain, limited throughput). | Accepted | none |
| 25 | No account management (disable user, password change, MFA) | Sessions are checked per request so disabling a user in SQL works instantly, but there is no UI for it. | **Open** | none |
| 26 | Admin cannot revoke a grant on someone else's document | Deliberate (least privilege) but means a departed owner's documents cannot be cleaned up in-app. | Open / design trade-off | none |
