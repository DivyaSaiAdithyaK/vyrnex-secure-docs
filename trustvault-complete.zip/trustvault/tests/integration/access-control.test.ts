import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Pool } from "pg";

// Point the app's db client at the disposable test database BEFORE importing any app code.
const url = process.env.DATABASE_URL_TEST;
if (!url) throw new Error("DATABASE_URL_TEST must point at a disposable test database");
process.env.DATABASE_URL = url;

type SU = import("@/server/authz/authorize").SessionUser;
const meta = { ip: "203.0.113.9", userAgent: "vitest" };
const pdf = (s = "x") => Buffer.concat([Buffer.from("%PDF-1.4\n"), Buffer.from(s)]);
const mk = (id: string, role: SU["role"]): SU => ({ id, email: `${role}-${id.slice(0, 4)}@t.test`, name: role, role });

let svc: typeof import("@/server/documents/service");
let auditMod: typeof import("@/server/audit");
let pool: Pool;
let owner: SU, owner2: SU, viewer: SU, viewer2: SU, admin: SU;
let docId: string;

async function seedUser(email: string, role: string) {
  const r = await pool.query("INSERT INTO users (email, name, password_hash, role) VALUES ($1,$1,'x',$2) RETURNING id", [email, role]);
  return { id: r.rows[0].id as string, email, name: email, role } as SU;
}
const status = (p: Promise<unknown>) => p.then(() => 200, (e) => e.status as number);
const auditCount = async (action: string, outcome: string) =>
  Number((await pool.query("SELECT count(*) FROM audit_events WHERE action=$1 AND outcome=$2", [action, outcome])).rows[0].count);

beforeAll(async () => {
  pool = new Pool({ connectionString: url, max: 3 });
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  const { runMigrations } = await import("../../scripts/migrate");
  await runMigrations(pool);
  svc = await import("@/server/documents/service");
  auditMod = await import("@/server/audit");
  owner = await seedUser("owner@t.test", "owner"); owner2 = await seedUser("owner2@t.test", "owner");
  viewer = await seedUser("viewer@t.test", "viewer"); viewer2 = await seedUser("viewer2@t.test", "viewer");
  admin = await seedUser("admin@t.test", "admin");
  const d = await svc.createDocument(owner, meta, { name: "Secret salary letter", description: "", category: "salary" }, { originalName: "letter.pdf", bytes: pdf("secret") });
  docId = d.id;
});
afterAll(async () => { await pool.end(); const { pool: appPool } = await import("@/server/db/client"); await appPool.end(); });

describe("one user cannot reach another user's documents", () => {
  it("owner can download their own document", async () => {
    const r = await svc.downloadDocument(owner, docId, meta);
    expect(r.bytes.toString()).toContain("secret");
  });

  it("a different owner with no grant is refused on EVERY operation, with the same 404 as a missing document", async () => {
    const missing = "00000000-0000-4000-8000-000000000000";
    expect(await status(svc.getDocument(owner2, docId, meta))).toBe(404);
    expect(await status(svc.downloadDocument(owner2, docId, meta))).toBe(404);
    expect(await status(svc.updateDocument(owner2, docId, meta, { name: "pwned" }))).toBe(404);
    expect(await status(svc.deleteDocument(owner2, docId, meta))).toBe(404);
    expect(await status(svc.listPermissions(owner2, docId, meta))).toBe(404);
    expect(await status(svc.grantPermission(owner2, docId, meta, viewer2.email, "read"))).toBe(404);
    expect(await status(svc.revokePermission(owner2, docId, meta, viewer.id))).toBe(404);
    expect(await status(svc.downloadDocument(owner2, missing, meta))).toBe(404); // indistinguishable
    const still = await svc.downloadDocument(owner, docId, meta);
    expect(still.doc.name).toBe("Secret salary letter"); // nothing was changed or deleted
  });

  it("refused attempts are written to the audit trail", async () => {
    expect(await auditCount("document.download", "denied")).toBeGreaterThanOrEqual(2);
    expect(await auditCount("document.delete", "denied")).toBeGreaterThanOrEqual(1);
  });

  it("the document never appears in another user's list or search results", async () => {
    for (const f of [{}, { q: "Secret" }, { q: "salary" }, { owner: "owner@t.test" }, { category: "salary" }]) {
      expect(await svc.listDocuments(owner2, f)).toHaveLength(0);
      expect(await svc.listDocuments(viewer, f)).toHaveLength(0);
    }
    expect((await svc.listDocuments(owner, { q: "Secret" })).length).toBe(1);
  });

  it("an administrator has no document access without a grant", async () => {
    expect(await status(svc.downloadDocument(admin, docId, meta))).toBe(404);
    expect(await svc.listDocuments(admin, {})).toHaveLength(0);
  });

  it("a viewer cannot upload", async () => {
    expect(await status(svc.createDocument(viewer, meta, { name: "x", description: "", category: "general" }, { originalName: "a.pdf", bytes: pdf() }))).toBe(403);
  });
});

describe("grants and immediate revocation", () => {
  it("read grant allows read and download but not edit, delete or sharing", async () => {
    await svc.grantPermission(owner, docId, meta, viewer.email, "read");
    expect((await svc.downloadDocument(viewer, docId, meta)).doc.id).toBe(docId);
    expect((await svc.listDocuments(viewer, {})).length).toBe(1);
    expect(await status(svc.updateDocument(viewer, docId, meta, { name: "x" }))).toBe(404);
    expect(await status(svc.deleteDocument(viewer, docId, meta))).toBe(404);
    expect(await status(svc.grantPermission(viewer, docId, meta, viewer2.email, "read"))).toBe(404);
  });

  it("edit grant allows edits but not delete or sharing", async () => {
    await svc.grantPermission(owner, docId, meta, viewer.email, "edit");
    await svc.updateDocument(viewer, docId, meta, { description: "edited by grantee" });
    expect(await status(svc.deleteDocument(viewer, docId, meta))).toBe(404);
    expect(await status(svc.listPermissions(viewer, docId, meta))).toBe(404);
  });

  it("revoking access works on the very next request", async () => {
    expect(await status(svc.downloadDocument(viewer, docId, meta))).toBe(200);
    await svc.revokePermission(owner, docId, meta, viewer.id);
    expect(await status(svc.downloadDocument(viewer, docId, meta))).toBe(404);
    expect(await status(svc.getDocument(viewer, docId, meta))).toBe(404);
    expect(await svc.listDocuments(viewer, {})).toHaveLength(0);
  });

  it("deleting a document removes it for everyone but keeps its audit history", async () => {
    const d = await svc.createDocument(owner, meta, { name: "temp", description: "", category: "general" }, { originalName: "t.txt", bytes: Buffer.from("hello") });
    await svc.grantPermission(owner, d.id, meta, viewer.email, "read");
    await svc.deleteDocument(owner, d.id, meta);
    expect(await status(svc.downloadDocument(viewer, d.id, meta))).toBe(404);
    expect((await auditMod.documentActivity(d.id)).some((e) => e.action === "document.delete")).toBe(true);
  });
});

describe("upload validation", () => {
  const up = (name: string, bytes: Buffer) => status(svc.createDocument(owner, meta, { name: "v", description: "", category: "general" }, { originalName: name, bytes }));
  it("rejects disallowed extensions, mismatched content, empty, oversized and binary 'text'", async () => {
    expect(await up("evil.exe", Buffer.from("MZ"))).toBe(400);
    expect(await up("fake.pdf", Buffer.from("<script>alert(1)</script>"))).toBe(400);
    expect(await up("empty.txt", Buffer.alloc(0))).toBe(400);
    expect(await up("big.pdf", pdf("a".repeat(4 * 1024 * 1024)))).toBe(400);
    expect(await up("bin.txt", Buffer.from([0x41, 0x00, 0x42]))).toBe(400);
  });
  it("accepts a valid pdf and strips path components from the file name", async () => {
    const d = await svc.createDocument(owner, meta, { name: "ok", description: "", category: "general" }, { originalName: "../../etc/ok.pdf", bytes: pdf() });
    expect(d.originalName).toBe("ok.pdf");
  });
});

describe("audit trail after all of the above", () => {
  it("records uploads, downloads, updates, deletions and permission changes", async () => {
    for (const [a, o] of [["document.upload", "success"], ["document.download", "success"], ["document.update", "success"], ["document.delete", "success"],
      ["permission.grant", "success"], ["permission.update", "success"], ["permission.revoke", "success"], ["document.upload", "denied"]] as const)
      expect(await auditCount(a, o), `${a}/${o}`).toBeGreaterThanOrEqual(1);
  });
  it("never stores file contents in the audit trail", async () => {
    const r = await pool.query("SELECT count(*) FROM audit_events WHERE details::text ILIKE '%secret%' AND action <> 'document.upload'");
    expect(Number(r.rows[0].count)).toBe(0);
  });
  it("the hash chain still verifies", async () => {
    const v = await auditMod.verifyChain();
    expect(v.ok).toBe(true);
    expect(v.checked).toBeGreaterThan(20);
  });
});
