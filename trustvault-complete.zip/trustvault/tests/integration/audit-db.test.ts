import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Pool } from "pg";
import { runMigrations } from "../../scripts/migrate";

const url = process.env.DATABASE_URL_TEST;
if (!url) throw new Error("DATABASE_URL_TEST must point at a disposable test database");
const pool = new Pool({ connectionString: url, max: 3 });

async function log(action: string, outcome = "success", details = {}) {
  const r = await pool.query(
    "INSERT INTO audit_events (seq, prev_hash, hash, action, outcome, details) VALUES (0,'','',$1,$2,$3) RETURNING seq, prev_hash, hash",
    [action, outcome, details]);
  return r.rows[0] as { seq: string; prev_hash: string; hash: string };
}
const verify = async () => (await pool.query("SELECT * FROM verify_audit_chain()")).rows[0];

beforeAll(async () => {
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  await runMigrations(pool);
});
afterAll(() => pool.end());

describe("audit trail integrity (real Postgres, no mocks)", () => {
  it("assigns seq, time and hash in the database and links each row to the previous one", async () => {
    const a = await log("document.upload");
    const b = await log("document.download", "denied");
    expect(a.prev_hash).toBe("0".repeat(64));
    expect(b.prev_hash).toBe(a.hash);
    expect(Number(b.seq)).toBeGreaterThan(Number(a.seq));
  });

  it("ignores caller-supplied seq/hash values (cannot forge chain fields on insert)", async () => {
    const r = await pool.query(
      "INSERT INTO audit_events (seq, prev_hash, hash, action, outcome) VALUES (999999,'forged','forged','x','success') RETURNING seq, hash");
    expect(r.rows[0].hash).not.toBe("forged");
    expect(Number(r.rows[0].seq)).not.toBe(999999);
  });

  it("rejects UPDATE", async () => {
    await expect(pool.query("UPDATE audit_events SET outcome='success', reason='cover-up'"))
      .rejects.toThrow(/append-only/);
  });
  it("rejects DELETE", async () => {
    await expect(pool.query("DELETE FROM audit_events")).rejects.toThrow(/append-only/);
  });
  it("rejects TRUNCATE", async () => {
    await expect(pool.query("TRUNCATE audit_events")).rejects.toThrow(/append-only/);
  });

  it("verifies a clean chain", async () => {
    const v = await verify();
    expect(v.ok).toBe(true);
    expect(Number(v.checked)).toBeGreaterThanOrEqual(3);
  });

  it("detects tampering by someone who bypasses the triggers (e.g. a DB superuser)", async () => {
    const victim = await log("document.download", "denied", { note: "evidence" });
    const c = await pool.connect();
    try {
      await c.query("ALTER TABLE audit_events DISABLE TRIGGER audit_no_update_delete");
      await c.query("UPDATE audit_events SET outcome='success' WHERE seq=$1", [victim.seq]);
      await c.query("ALTER TABLE audit_events ENABLE TRIGGER audit_no_update_delete");
    } finally { c.release(); }
    const v = await verify();
    expect(v.ok).toBe(false);
    expect(String(v.broken_seq)).toBe(String(victim.seq));
  });
});
