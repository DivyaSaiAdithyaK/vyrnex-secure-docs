import { randomBytes } from "node:crypto";
import { pool } from "../src/server/db/client";
import { hashPassword } from "../src/server/auth/password";

// Demo accounts: one per role, plus a second owner and viewer so we can demonstrate
// "a user with no grant is denied". Passwords come from env or are generated and printed once.
const ACCOUNTS = [
  { email: "admin@trustvault.demo",   name: "Ada Admin",    role: "admin",  env: "SEED_PASSWORD_ADMIN" },
  { email: "owner@trustvault.demo",   name: "Olivia Owner", role: "owner",  env: "SEED_PASSWORD_OWNER" },
  { email: "owner2@trustvault.demo",  name: "Omar Owner",   role: "owner",  env: "SEED_PASSWORD_OWNER" },
  { email: "viewer@trustvault.demo",  name: "Vik Viewer",   role: "viewer", env: "SEED_PASSWORD_VIEWER" },
  { email: "viewer2@trustvault.demo", name: "Vera Viewer",  role: "viewer", env: "SEED_PASSWORD_VIEWER" },
] as const;

async function main() {
  const generated: Record<string, string> = {};
  for (const a of ACCOUNTS) {
    const pw = process.env[a.env] || (generated[a.env] ??= randomBytes(9).toString("base64url"));
    await pool.query(
      `INSERT INTO users (email, name, password_hash, role) VALUES ($1,$2,$3,$4)
       ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, name = EXCLUDED.name,
         role = EXCLUDED.role, disabled_at = NULL`,
      [a.email, a.name, await hashPassword(pw), a.role]);
  }
  console.log(`Seeded ${ACCOUNTS.length} demo users.`);
  for (const [k, v] of Object.entries(generated)) console.log(`  generated ${k} = ${v}  (shown once)`);
  await pool.end();
}
main().catch((e) => { console.error(e.message); process.exit(1); });
