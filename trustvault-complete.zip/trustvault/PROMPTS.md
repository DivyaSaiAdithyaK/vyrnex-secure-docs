# PROMPTS.md: how AI was used on TrustVault

Written as I go. Entries are only added for things that actually happened. Anything not yet done is marked PENDING.
Reusable instructions I give the AI every session are in [AGENTS.md](AGENTS.md).

## Entry 1: 2026-10-25: audit-trail design (AUDIT TRAIL / ACCESS CONTROL entry)

**Asked:** I gave the AI a long "master prompt" plus photos of the challenge brief and asked it to plan and start building
TrustVault. Its first plan covered "immutable audit" with a single database trigger that blocks UPDATE and DELETE.

**It produced:** that trigger-only design, presented as the answer to "what stops the audit trail being altered?"

**What was wrong or incomplete (specifically):**
- A trigger can be disabled by the table owner or a superuser (`ALTER TABLE ... DISABLE TRIGGER`), so it stops the *app*
  but not an attacker or insider with DB access. The brief says "an audit trail that can be quietly altered is not evidence".
- Nothing would have *detected* an edit made that way.

**What I did instead:** added a SHA-256 hash chain computed by a database trigger (the app cannot set `seq`, `at`,
`prev_hash` or `hash`), plus `verify_audit_chain()` which recomputes everything and reports the first bad row.
Kept the append-only triggers too (defence in depth).

**How I checked:** `tests/integration/audit-db.test.ts` uses a real Postgres. One test disables the trigger, edits a row,
and asserts verification fails at exactly that row. I also removed the UPDATE/DELETE trigger from the migration and reran:
4 of 7 tests failed; restoring it made all 7 pass.

**Commit:** 31e1894

**Known remaining gap (not fixed yet):** deleting the *newest* rows leaves a valid chain. Mitigation planned: expose the
chain head hash to admins and record it outside the database. PENDING (will be written up in THREATS.md).

## Entry 2: PENDING (authorisation entry, to be written when a real mistake is found during Milestone 2)
## Entry 3: PENDING
## Entry 4: PENDING
## Entry 5: PENDING
